    
public class Wrapper3{
    public static void main(String[] args)
    {
        int i = Integer.parseInt("40");
        double d = Double.parseDouble("18.5");
        boolean b = Boolean.parseBoolean("false");
        System.out.println(i);
        System.out.println(d);
        System.out.println(b);
    }
}